#pragma once
#include <SFML/Graphics.hpp>
#include "RoundWordUI.hpp"

class WordSUI : public RoundWordUI {
public:
	// Default constructor
	WordSUI(sf::Vector2f spawnPoint);
};