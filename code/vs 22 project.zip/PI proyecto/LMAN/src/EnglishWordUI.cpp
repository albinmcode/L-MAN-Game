#include "SpanishWordUI.hpp"
#include <iostream>

WordSUI::WordSUI(sf::Vector2f spawnPoint)
	: RoundWordUI(spawnPoint) {}